import React, { useState } from 'react';
import { View, TouchableOpacity, Text, StyleSheet, ScrollView, ImageBackground } from 'react-native';

const flexboxproperties = () => {
  const [flexboxdirection, setFlexboxdirection] = useState('row');
  const [flexboxcontents, setFlexboxcontents] = useState('flex-start');
  const [flexboxitemallignment, setFlexboxitemallignment] = useState('flex-start');
  const [flexboxcontentallignment, setFlexboxcontentallignment] = useState('flex-start');
  const [flexboxwrapnowrap, setFlexboxwrapnowrap] = useState('wrap');

  return (
    <ImageBackground 
      source={require('./assets/fam.jpg')} 
      style={styles.container}
      imageStyle={styles.backgroundImage}
    >
      <ScrollView contentContainerStyle={styles.scrollViewContent}>
        <Flexboxblocking 
          flexboxlabel="flexboxdirection"
          options={['row', 'column', 'row-reverse', 'column-reverse']}
          flexboxvalue={flexboxdirection}
          setFlexboxvalue={setFlexboxdirection}
          flexboxstylekey="flexDirection"
        />
        <Text style={styles.divider}>================================================</Text>
        <Flexboxblocking 
          flexboxlabel="flexboxcontents"
          options={['flex-start', 'flex-end', 'center', 'space-between', 'space-around', 'space-evenly']}
          flexboxvalue={flexboxcontents}
          setFlexboxvalue={setFlexboxcontents}
          flexboxstylekey="justifyContent"
        />
        <Text style={styles.divider}>================================================</Text>
        <Flexboxblocking 
          flexboxlabel="flexboxitemallignment"
          options={['flex-start', 'flex-end', 'center', 'stretch', 'baseline']}
          flexboxvalue={flexboxitemallignment}
          setFlexboxvalue={setFlexboxitemallignment}
          flexboxstylekey="alignItems"
        />
        <Text style={styles.divider}>================================================</Text>
        <Flexboxblocking 
          flexboxlabel="flexboxcontentallignment"
          options={['flex-start', 'flex-end', 'center', 'stretch', 'space-between', 'space-around']}
          flexboxvalue={flexboxcontentallignment}
          setFlexboxvalue={setFlexboxcontentallignment}
          flexboxstylekey="alignContent"
        />
        <Text style={styles.divider}>================================================</Text>
        <Flexboxblocking 
          flexboxlabel="flexboxwrapnowrap"
          options={['wrap', 'nowrap']}
          flexboxvalue={flexboxwrapnowrap}
          setFlexboxvalue={setFlexboxwrapnowrap}
          flexboxstylekey="flexWrap"
        />
        <Text style={styles.divider}>================================================</Text>
      </ScrollView>
    </ImageBackground>
  );
};

const Flexboxblocking = ({ flexboxlabel, options, flexboxvalue, setFlexboxvalue, flexboxstylekey }) => {
  const nameParts = [
    "HONEY",
    "GRACE",
    "DEMDAM"
  ];

  return (
    <View style={{ padding: 10, flex: 1 }}>
      <Text style={styles.label}>{flexboxlabel}</Text>
      <View style={styles.row}>
        {options.map(option => (
          <TouchableOpacity
            key={option}
            onPress={() => setFlexboxvalue(option)}
            style={[styles.button, flexboxvalue === option && styles.selected]}>
            <Text style={[styles.buttonLabel, flexboxvalue === option && styles.selectedLabel]}>
              {option}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
      <View style={[styles.boxContainer, { [flexboxstylekey]: flexboxvalue }]}>
        {nameParts.map((part, partIndex) => (
          <View key={partIndex} style={styles.partContainer}>
            {part.split('').map((letter, letterIndex) => (
              <View key={letterIndex} style={[styles.box, { backgroundColor: getRandomColor() }]}>
                <Text style={styles.boxText}>{letter}</Text>
              </View>
            ))}
            {partIndex < nameParts.length - 1 && (
              <View style={[styles.box, { width: 20, height: 80, backgroundColor: 'transparent' }]} />
            )}
          </View>
        ))}
      </View>
    </View>
  );
};

const getRandomColor = () => {
  const colors = ['green', 'blue', 'purple', 'yellow', 'orange', 'red'];
  return colors[Math.floor(Math.random() * colors.length)];
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backgroundImage: {
    resizeMode: 'cover',
    flex: 1,
  },
  scrollViewContent: {
    flexGrow: 1,
  },
  boxContainer: {
    flex: 1,
    flexWrap: 'wrap',
    marginTop: 8,
    backgroundColor: 'transparent',
    maxHeight: 400,
  },
  partContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  box: {
    width: 50,
    height: 80,
    justifyContent: 'center',
    alignItems: 'center',
  },
  boxText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'white',
  },
  row: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  button: {
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 4,
    backgroundColor: 'oldlace',
    alignSelf: 'flex-start',
    marginHorizontal: '1%',
    marginBottom: 6,
    minWidth: '48%',
    textAlign: 'center',
  },
  selected: {
    backgroundColor: 'coral',
    borderWidth: 0,
  },
  buttonLabel: {
    fontSize: 12,
    fontWeight: '500',
    color: 'coral',
  },
  selectedLabel: {
    color: 'white',
  },
  label: {
    textAlign: 'center',
    marginBottom: 10,
    fontSize: 24,
  },
  divider: {
    textAlign: 'center',
    fontSize: 18,
    fontWeight: 'bold',
    color: 'black',
    marginVertical: 10,
    width: '100%',
  },
});

export default flexboxproperties;
